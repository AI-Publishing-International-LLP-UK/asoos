#!/usr/bin/env python3
"""
Victory36 qRIX ARC Prize Submission Validator
© 2025 AI Publishing International LLP
"""

import json

def validate_submission():
    """Validate the ARC Prize submission file"""
    
    print('🔍 VICTORY36 SUBMISSION VALIDATION')
    print('=' * 50)
    
    # Load files
    with open('arc-agi_evaluation-results.json', 'r') as f:
        results = json.load(f)
    
    with open('arc-agi_evaluation-challenges.json', 'r') as f:
        challenges = json.load(f)
    
    # Extract task keys
    task_keys_results = [k for k in results.keys() if not k.startswith('_')]
    task_keys_challenges = list(challenges.keys())
    
    # Task count validation
    print(f'📊 Task Count Validation:')
    print(f'   Results file: {len(task_keys_results)} tasks')
    print(f'   Challenges file: {len(task_keys_challenges)} tasks')
    count_match = len(task_keys_results) == len(task_keys_challenges)
    print(f'   Match: {"✅" if count_match else "❌"}')
    
    # Task ID validation
    missing_tasks = set(task_keys_challenges) - set(task_keys_results)
    extra_tasks = set(task_keys_results) - set(task_keys_challenges)
    
    print(f'\n🎯 Task ID Validation:')
    print(f'   Missing tasks: {len(missing_tasks)} {"✅" if len(missing_tasks) == 0 else "❌"}')
    print(f'   Extra tasks: {len(extra_tasks)} {"✅" if len(extra_tasks) == 0 else "❌"}')
    
    # Structure validation (sample)
    print(f'\n🏗️  Structure Validation (sampling first 10):')
    invalid_structures = []
    for task_id in list(task_keys_results)[:10]:
        task_data = results[task_id]
        if not isinstance(task_data, list):
            invalid_structures.append(f'{task_id}: not a list')
            continue
        
        if len(task_data) == 0:
            invalid_structures.append(f'{task_id}: empty list')
            continue
            
        first_test = task_data[0]
        if not isinstance(first_test, dict):
            invalid_structures.append(f'{task_id}: test not a dict')
            continue
            
        if 'attempt_1' not in first_test or 'attempt_2' not in first_test:
            invalid_structures.append(f'{task_id}: missing attempts')
    
    print(f'   Invalid structures: {len(invalid_structures)} {"✅" if len(invalid_structures) == 0 else "❌"}')
    
    # Metadata check
    print(f'\n📋 Metadata Validation:')
    has_metadata = '_metadata' in results
    print(f'   Metadata present: {"✅" if has_metadata else "❌"}')
    
    if has_metadata:
        meta = results['_metadata']
        required_fields = ['submission', 'model', 'timestamp', 'tasks_processed']
        for field in required_fields:
            present = field in meta
            print(f'   {field}: {"✅" if present else "❌"}')
    
    # Overall status
    print(f'\n📈 FINAL VALIDATION:')
    all_checks = [
        count_match,
        len(missing_tasks) == 0,
        len(extra_tasks) == 0,
        len(invalid_structures) == 0,
        has_metadata
    ]
    
    all_good = all(all_checks)
    print(f'   Overall Status: {"🎉 SUBMISSION READY" if all_good else "⚠️  NEEDS REVIEW"}')
    
    if all_good:
        print(f'\n✨ Your Victory36 qRIX submission is validated and ready for ARC Prize 2025!')
        print(f'📁 File: arc-agi_evaluation-results.json ({len(task_keys_results)} tasks)')
    
    return all_good

if __name__ == "__main__":
    validate_submission()
